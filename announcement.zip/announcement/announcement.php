<?php
    // Check if the user is logged in and has a role
    if (isset($_SESSION['login_type'])) {
        $userRole = $_SESSION['login_type'];
    } else {
        $userRole = 'client'; // Default to 'client' if the role is not set
    }
?>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	

<div class="col-lg-12">
	<h1 class="page-header text-center">Announcements</h1>
	<div class="row">
		<div class="col-sm-8 col-sm-offset-2">
		<?php if ($userRole === '1'): ?>
			<a href="#addnew" class="btn btn-primary" data-toggle="modal"><span class="glyphicon glyphicon-plus"></span> New</a>
			
			<?php endif; ?>
            <?php 
                if(isset($_SESSION['message'])){
                    ?>
                    <div class="alert alert-info text-center" style="margin-top:20px;">
                        <?php echo $_SESSION['message']; ?>
                    </div>
                    <?php

                    unset($_SESSION['message']);
                }
            ?>
			<table class="table table-bordered table-striped" style="margin-top:20px;">
				<thead>
					<th>ID</th>
					<th>Date Uploaded</th>
					<th>Picture</th>
					<th>Description</th>
					<th>Date Event</th>
					<?php if ($userRole === '1'): ?><th>Action</th><?php endif; ?>
				</thead>
				<tbody>
					<?php
						//include our connection
						include_once('connection.php');
						$database = new Connection();
    					$db = $database->open();
						try{	
						    $sql = 'SELECT * FROM announcement';
						    foreach ($db->query($sql) as $row) {
								
						    	?>
						    	<tr>
						    		<td><?php echo $row['id']; ?></td>
						    		<td><?php echo $row['dateupload']; ?></td>
						    		<td><?php
										$imagePath = 'assets/announcement_img/' . $row['image'];
										if (file_exists($imagePath)) {
											echo '<img src="' . $imagePath . '" class="img-responsive img-thumbnail" width="150" height="150">';
										} else {
											echo 'Image not found';
										}
										?>
									</td>
						    		<td><?php echo $row['description']; ?></td>
									<td><?php echo $row['dateevent']; ?></td>
									<?php if ($userRole === '1'): ?>
						    		<td>
						    			<a href="#edit_<?php echo $row['id']; ?>" class="btn btn-success btn-sm" data-toggle="modal"><span class="glyphicon glyphicon-edit"></span> Edit</a>
										
						    			<a href="#delete_<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" data-toggle="modal"><span class="glyphicon glyphicon-trash"></span> Delete</a>
										
										
						    		</td><?php endif; ?>
						    		<?php include('edit_delete_announcement.php'); ?>
									
						    	</tr>
						    	<?php 
								
						    }
						}
						catch(PDOException $e){
							echo "There is some problem in connection: " . $e->getMessage();
						}

						//close connection
						$database->close();

					?>
				</tbody>
			</table>
			</div>
	</div>
</div>
<script>
function displayImg(input,_this) {
	    if (input.files && input.files[0]) {
	        var reader = new FileReader();
	        reader.onload = function (e) {
	        	$('#cimg').attr('src', e.target.result);
	        }

	        reader.readAsDataURL(input.files[0]);
	    }
	}</script>

<?php include('add_modal.php'); ?>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="jquery.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>


